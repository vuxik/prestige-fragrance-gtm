# Salon Fragrance GTM Calculator & Advisor

Brand-agnostic calculator for high-end salon fragrance (typical price £150–£200 for 30/50 ml).

## Quick start (CLI)
```bash
pip install -r requirements.txt
python core_cli.py --config sample_config.yaml --out report.md
```
