# Salon Fragrance GTM — Calculator Report

## Inputs

- Price: £180 (30/50 ml)
- GM%: 80%
- CAC: £35
- Horizon: 24 months

- Baseline weekly units: 100.0
- Weeks simulated: 26
- Elasticity: 1.1

- Promo events:

  - Week 6: depth 15% (Retail)

  - Week 15: depth 20% (DTC)

  - Week 22: depth 15% (Retail)


## Core Economics

- LTV (GM-basis): **£99.39** per acquired customer

- CAC payback month: **4**


## Promo Evaluation

- Net GM delta vs baseline (after trough): **£517.93** over 26 weeks

- Avg depth: 16.7%; Promo weeks share: 11.5%

- Pull-forward share (assumed): 35%; Cannibalization share (assumed): 25%

- Post-promo baseline recovery (proxy): ~2.6 weeks


## Prestige Protection

- PPI score: **16.5 / 100**


## Advisor — Recommended Actions

- Prestige protected: maintain current guardrails; consider shifting one sitewide promo to a discovery-set-with-credit event.

- Promo plan marginal: reallocate one promo to discovery bundle; protect hero SKUs at list.

- Payback within 12 months: scale channels with similar CAC.
